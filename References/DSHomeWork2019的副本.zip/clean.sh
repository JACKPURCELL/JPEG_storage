#!/bin/bash
rm -rf ./build/*
rm -rf ./bin/*
rm -rf ./bin/.StorageConfig
rm -rf ./lib/*.a