
# Requirements

1. `2` members for each group at most. They will get the same grade.
2. Use a meaning full suffix for your repo (like your name).
3. The final submission **MUST** be in branch `master`.
4. Directory layout
   - `members.md`: list group members.
   - `report.pdf`: final report **MUST** be in `PDF`.
   - `src/`: Source codes **MUST** be also available.
   - `bin/`: provide the binaries if it is applicable.


# Project UDS README

## Dependencies

* Openssl v1.1.1c
* Google leveldb
* Boost Library

## Configurations

Using `init.sh` to configure the system, while using `clean.sh` to clean up.
All exec will listed in bin/

## Usage
### Settings

Edit `config.json` to set up server informations and other configurations in the system.

### Upload File

After setup `config.json` and start `server`, at client side :  
```
./client -s PATH_TO_FILE
```

### Upload File

```
./client -r PATH_TO_FILE
```

The downloaded file store at the same path with `FILE_NAME.d` format.